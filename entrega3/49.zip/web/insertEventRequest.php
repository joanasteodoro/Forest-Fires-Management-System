<html>
    <body>
        <link rel="stylesheet" href="index.css">
        <h3>Insert</h3>
        <form action="insertEvent.php" method="post">
            <p>Phone Number: <input type="text" name="numTelefone"/></p>
            <p>Call Time: <input type="text" name="instanteChamada"/></p>
            <p>Witness Name: <input type="text" name="nomePessoa"/></p>
            <p>Address: <input type="text" name="moradaLocal"/></p>
            <p>Rescue Process Number: <input type="text" name="numProcessoSocorro"/></p>

            <p><input type="submit" value="Submit"/></p>
        </form>
    </body>
</html>

<html>
    <body>
      <link rel="stylesheet" href="index.css">
        <h3>Insert</h3>
        <form action="insertEntity.php" method="post">
            <p>Entity Name: <input type="text" name="nomeEntidade"/></p>

            <p><input type="submit" value="Submit"/></p>
        </form>
    </body>
</html>

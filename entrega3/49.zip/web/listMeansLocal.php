<html>
    <body>
      <link rel="stylesheet" href="index.css">
        <h3>List Means accionated by a Rescue Process at a certain Local</h3>
        <form action="listMeioAccionado.php" method="post">
            <p>Rescue Process: <input type="text" name="numprocessosocorro"/></p>
        <form action="listMeioAccionado.php" method="post">
            <p>Local: <input type="text" name="moradaLocal"/></p>

            <p><input type="submit" value="Submit"/></p>
        </form>
    </body>
</html>

<html>
    <body>
        <link rel="stylesheet" href="index.css">
        <h3>Associate</h3>
        <form action="associateProcessesMeans.php" method="post">
            <p>Rescue Process Number: <input type="text" name="numProcessoSocorro"/></p>
            <p>Mean Number:<input type="text" name="numMeio"/></p>
            <p>Entity Name:<input type="text" name="nomeEntidade"/></p>

            <p><input type="submit" value="Submit"/></p>
        </form>
    </body>
</html>

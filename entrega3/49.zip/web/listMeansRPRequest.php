<html>
    <body>
      <link rel="stylesheet" href="index.css">
        <h3>List Means accionated by a Rescue Process</h3>
        <form action="listMeansRP.php" method="post">
            <p>Rescue Process: <input type="text" name="numprocessosocorro"/></p>
            <p><input type="submit" value="Submit"/></p>
        </form>
    </body>
</html>

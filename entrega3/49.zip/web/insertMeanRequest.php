<html>
    <body>
      <link rel="stylesheet" href="index.css">
        <h3>Insert</h3>
        <form action="insertMean.php" method="post">
            <p>Mean Number: <input type="text" name="numMeio"/></p>
            <p>Mean Name: <input type="text" name="nomeMeio"/></p>
            <p>Entity name: <input type="text" name="nomeEntidade"/></p>


            <p><input type="submit" value="Submit"/></p>
        </form>
    </body>
</html>
